﻿(function () {
    'use strict';

    //var app = angular.module('myApp', ['ui.bootstrap']);
    //app.controller('inspectiondetailCtrl', inspectiondetailCtrl);
    angular.module('myApp')
        .controller('inspectiondetailCtrl', inspectiondetailCtrl);

    app.filter('startFrom', function () {
        return function (input, start) {
            if (input) {
                start = +start;
                return input.slice(start);
            }
            return [];
        };
    });

    app.filter('propsFilter', function () {
        return function (items, props) {
            var out = [];

            if (angular.isArray(items)) {
                items.forEach(function (item) {
                    var itemMatches = false;

                    var keys = Object.keys(props);
                    for (var i = 0; i < keys.length; i++) {
                        var prop = keys[i];
                        var text = props[prop].toLowerCase();
                        if (item[prop].toString().toLowerCase().indexOf(text) !== -1) {
                            itemMatches = true;
                            break;
                        }
                    }

                    if (itemMatches) {
                        out.push(item);
                    }
                });
            } else {
                // Let the output be the input untouched
                out = items;
            }

            return out;
        };
    });


    var PDFFileList = [];

    app.controller('ImageUploadMultipleCtrl', function ($scope) {

        $scope.fileList = [];
        $scope.curFile;
        $scope.FileProperty = {
            FileDrawingNamePath: ''
        }

        $scope.setFile = function (element) {
            $scope.fileList = [];
            // get the files
            var files = element.files;
            for (var i = 0; i < files.length; i++) {
                $scope.FileProperty.file = files[i];

                $scope.fileList.push($scope.FileProperty);
                $scope.FileProperty = {};
                $scope.$apply();

            }
        }
        PDFFileList = $scope.fileList;
        console.log('--------------------File list----------------', PDFFileList);
    });

    

    inspectiondetailCtrl.$inject = ['$scope', '$http'];

    function inspectiondetailCtrl($scope, $http) {

        $scope.viewby = '50';
        $scope.currentPage = '1';
        $scope.itemsPerPage = $scope.viewby;
        $scope.maxSize = '10'; //Number of pager buttons to show
        $scope.setPage = function (pageNo) {
            $scope.currentPage = pageNo;
        };
        $scope.pageChanged = function () { };
        $scope.setItemsPerPage = function (num) {
            $scope.itemsPerPage = num;
            $scope.currentPage = 1; //reset to first page
        }

        $scope.inspectionDate = new Date();

        //$http.get('/api/pageview/getAllCustomers').then(function (response) {
        //    $scope.getAllCustomers = response.data;
        //    console.log('$scope.getAllCustomers', $scope.getAllCustomers);
        //    if ($scope.getAllCustomers != null) { $scope.getAllCustomerscount = $scope.getAllCustomers.length; }
        //    else { $scope.getAllCustomerscount = 0; }
        //    $scope.totalgetAllCustomers = $scope.getAllCustomerscount;
        //}, function (response) {
        //    $scope.waiting = false;
        //});

        //$http.get('/api/pageview/getAllEmployee').then(function (response) {
        //    $scope.getAllEmployee = response.data;
        //    console.log('$scope.getAllEmployee', $scope.getAllEmployee);
        //    if ($scope.getAllEmployee != null) { $scope.getAllEmployeecount = $scope.getAllEmployee.length; }
        //    else { $scope.getAllEmployeecount = 0; }
        //    $scope.totalemployee = $scope.getAllEmployeecount;
        //}, function (response) {
        //    $scope.waiting = false;
        //});

        $http.get('/api/pageview/getAllStampingEmployee').then(function (response) {
            $scope.getAllStampingEmployee = response.data;
            console.log('$scope.getAllStampingEmployee', $scope.getAllStampingEmployee);
        }, function (response) {
            $scope.waiting = false;
        });

        //if (window.location.pathname != "/Admin/EditInspectionDue") {

        //    $http.get('/api/pageview/getAllFacilitiesArea').then(function (response) {
        //        $scope.getAllFacilitiesArea = response.data;
        //        console.log('$scope.getAllFacilitiesArea', $scope.getAllFacilitiesArea);
        //        if ($scope.getAllFacilitiesArea != null) { $scope.getAllFacilitiesAreacount = $scope.getAllFacilitiesArea.length; }
        //        else { $scope.getAllFacilitiesAreacount = 0; }
        //        $scope.totalgetAllFacilitiesArea = $scope.getAllFacilitiesAreacount;
        //    }, function (response) {
        //        $scope.waiting = false;
        //    });

        //    $http.get('/api/pageview/getAllProcessOverview').then(function (response) {
        //        $scope.getAllProcessOverview = response.data;
        //        console.log('$scope.getAllProcessOverview', $scope.getAllProcessOverview);
        //        if ($scope.getAllProcessOverview != null) { $scope.getAllProcessOverviewcount = $scope.getAllProcessOverview.length; }
        //        else { $scope.getAllProcessOverviewcount = 0; }
        //        $scope.totalgetAllProcessOverview = $scope.getAllProcessOverviewcount;
        //    }, function (response) {
        //        $scope.waiting = false;
        //    });

        //    $http.get('/api/pageview/getAllDocumentTitle').then(function (response) {
        //        $scope.getAllDocumentTitle = response.data;
        //        console.log('$scope.getAllDocumentTitle', $scope.getAllDocumentTitle);
        //        if ($scope.getAllDocumentTitle != null) { $scope.getAllDocumentTitlecount = $scope.getAllDocumentTitle.length; }
        //        else { $scope.getAllDocumentTitlecount = 0; }
        //        $scope.totalgetAllDocumentTitlecount = $scope.getAllDocumentTitlecount;
        //    }, function (response) {
        //        $scope.waiting = false;
        //    });
        //}

        $http.get('/api/pageview/getAllInspection').then(function (response) {
            $scope.getAllInspection = response.data;
            console.log('$scope.getAllInspection', $scope.getAllInspection);
            if ($scope.getAllInspection != null) { $scope.getAllInspectioncount = $scope.getAllInspection.length; }
            else { $scope.getAllInspectioncount = 0; }
            $scope.totalgetAllInspection = $scope.getAllInspectioncount;
        }, function (response) {
            $scope.waiting = false;
        });

        $http.get('/api/pageview/getAllInspectionByEmployeeId').then(function (response) {
            $scope.getAllInspectionByEmployeeId = response.data;
            console.log('$scope.getAllInspectionByEmployeeId', $scope.getAllInspectionByEmployeeId);
            if ($scope.getAllInspectionByEmployeeId != null) { $scope.getAllInspectionByEmployeeIdcount = $scope.getAllInspectionByEmployeeId.length; }
            else { $scope.getAllInspectionByEmployeeIdcount = 0; }
            $scope.totalgetAllInspectionByEmployeeId = $scope.getAllInspectionByEmployeeIdcount;
        }, function (response) {
            $scope.waiting = false;
        });

        $http.get('/api/pageview/getAllInspectionByCustomerId').then(function (response) {
            $scope.getAllInspectionByCustomerId = response.data;
            console.log('$scope.getAllInspectionByCustomerId', $scope.getAllInspectionByCustomerId);
            if ($scope.getAllInspectionByCustomerId != null) { $scope.getAllInspectionByCustomerIdcount = $scope.getAllInspectionByCustomerId.length; }
            else { $scope.getAllInspectionByCustomerIdcount = 0; }
            $scope.totalgetAllInspectionByCustomerId = $scope.getAllInspectionByCustomerIdcount;
        }, function (response) {
            $scope.waiting = false;
        });

        $scope.InspectionDetailClickByCustomer = function (id) {
            $http.get('/api/pageview/getInspectionById', { params: { InspectionId: id } }).then(function (response) {
                $scope.getInspectionById = response.data;
                if ($scope.getInspectionById.InspectionStatus == 3 || $scope.getInspectionById.InspectionStatus == 4) {
                    var url = '/Customer/InspectionDetails?id=' + id; //InspectionId
                    window.location = url;
                }
            }, function (response) {
                $scope.waiting = false;
            });
        };

        $scope.InspectionsheetClick = function (id) {
            var url = '/Admin/InspectionSheet?id=' + id;
            window.location = url;
        };

        $scope.InspectionDetailByEmployeeClick = function (id) {
            var url = '/Employee/InspectionDetail?id=' + id;
            window.location = url;
        };

        $http.get('/api/pageview/getAllDueInspection').then(function (response) {
            $scope.getAllDueInspection = response.data;
            console.log('$scope.getAllDueInspection', $scope.getAllDueInspection);
            if ($scope.getAllDueInspection != null) { $scope.getAllDueInspectioncount = $scope.getAllDueInspection.length; }
            else { $scope.getAllDueInspectioncount = 0; }
            $scope.totalgetAllDueInspection = $scope.getAllDueInspectioncount;
        }, function (response) {
            $scope.waiting = false;
        });

        $http.get('/api/pageview/getAllInspectionType').then(function (response) {
            $scope.getAllInspectionType = response.data;
            console.log('$scope.getAllInspectionType', $scope.getAllInspectionType);
            if ($scope.getAllInspectionType != null) { $scope.getAllInspectionTypecount = $scope.getAllInspectionType.length; }
            else { $scope.getAllInspectionTypecount = 0; }
        }, function (response) {
            $scope.waiting = false;
        });

        $scope.GetCustomerLocationByCustomerIdDrpd = function (id) {
            console.log('GetLocationbyCustomerDrpd', id);
            $http.get('/api/pageview/getCustomerLocationByCustomerId', { params: { id: id } }).then(function (response) {
                $scope.getCustomerLocationByCustomerIdDrpd = response.data;
                console.log('getCustomerLocationByCustomerIdDrpd--', $scope.getCustomerLocationByCustomerIdDrpd);
            }, function (response) {
                $scope.waiting = false;
            });
        };

        $scope.GetAreaByLocationIdDrpd = function (id) {
            console.log('getAreaDetailsByLocationId', id);
            $http.get('/api/pageview/getAreaDetailsByLocationId', { params: { id: id } }).then(function (response) {
                $scope.getAreaDetailsByLocationId = response.data;
                console.log('getAreaDetailsByLocationId--', $scope.getAreaDetailsByLocationId);
            }, function (response) {
                $scope.waiting = false;
            });
        };

        //if (window.location.pathname == "/Admin/EditInspectionDue") {

        //    $http.get('/api/pageview/getAllFacilitiesArea').then(function (response) {
        //        $scope.getAllFacilitiesArea = response.data;
        //    }, function (response) {
        //        $scope.waiting = false;
        //    });

        //    $http.get('/api/pageview/getAllProcessOverview').then(function (response) {
        //        $scope.getAllProcessOverview = response.data;
        //    }, function (response) {
        //        $scope.waiting = false;
        //    });

        //    $http.get('/api/pageview/getAllDocumentTitle').then(function (response) {
        //        $scope.getAllDocumentTitle = response.data;
        //    }, function (response) {
        //        $scope.waiting = false;
        //    });

        //    $http.get('/api/pageview/getAllCustomerLocations').then(function (response) {
        //        $scope.getCustomerLocationByCustomerIdDrpd = response.data;
        //        console.log('getAllCustomerLocations0000--', $scope.getCustomerLocationByCustomerIdDrpd);
        //    }, function (response) {
        //        $scope.waiting = false;
        //    });

        //    $http.get('/api/pageview/getAllCustomerArea').then(function (response) {
        //        $scope.getAreaDetailsByLocationId = response.data;
        //        console.log('getAllCustomerArea0000--', $scope.getAreaDetailsByLocationId);
        //    }, function (response) {
        //        $scope.waiting = false;
        //    });

        //    var para = window.location.search;
        //    para = para.replace('?id=', '');
        //    $http.get('/api/pageview/getInspectionById', { params: { InspectionId: para } }).then(function (response) {
        //        $scope.getInspectionById = response.data;
        //        var process = $scope.getInspectionById.ProcessOverviewIds;
        //        var document = $scope.getInspectionById.ReferenceDocumentIds;
        //        var facilities = $scope.getInspectionById.FacilitiesAreasIds;

        //        angular.forEach($scope.getAllFacilitiesArea, function (f) {
        //            if (facilities.indexOf(f.FacilitiesAreaId) > -1) {
        //                f.selected = true;
        //            }
        //        });

        //        angular.forEach($scope.getAllProcessOverview, function (p) {
        //            if (process.indexOf(p.ProcessOverviewId) > -1) {
        //                p.selected = true;
        //            }
        //        });
        //        angular.forEach($scope.getAllDocumentTitle, function (t) {
        //            if (document.indexOf(t.DocumentId) > -1) {
        //                t.selected = true;
        //            }
        //        });
        //    }, function (response) {
        //        $scope.waiting = false;
        //    });

        //    $scope.ShowDatepicker = false;
        //    $scope.ReadOnlyDatePicker = true;
        //}

        if (window.location.pathname == "/CustomerLocationContact/ManageInspection") {
            $http.get('/api/pageview/getInspectionByContactId').then(function (response) {
                $scope.getInspectionByContactId = response.data;
                console.log('$scope.getInspectionByContactId123123', $scope.getInspectionByContactId);
                if ($scope.getInspectionByContactId != null) { $scope.getInspectionByContactIdcount = $scope.getInspectionByContactId.length; }
                else { $scope.getInspectionByContactIdcount = 0; }
                $scope.totalgetInspectionByContactId = $scope.getInspectionByContactIdcount;
            }, function (response) {
                $scope.waiting = false;
            });
        }

        $scope.GetCheckedFacilitiesAndProcess = function () {
            var checkedFacilities = '';
            $scope.getAllFacilitiesArea.forEach(function (f) {
                if (f.selected) {
                    if (checkedFacilities != '') {
                        checkedFacilities += ",";
                    }
                    checkedFacilities += f.FacilitiesAreaId;
                }
            });
            $scope.checkedFacilitiesId = checkedFacilities;

            var checkedProcess = '';
            $scope.getAllProcessOverview.forEach(function (p) {
                if (p.selected) {
                    if (checkedProcess != '') {
                        checkedProcess += ",";
                    }
                    checkedProcess += p.ProcessOverviewId;
                }
            });
            $scope.checkedProcessId = checkedProcess;

            var checkedDocument = '';
            $scope.getAllDocumentTitle.forEach(function (t) {
                if (t.selected) {
                    if (checkedDocument != '') {
                        checkedDocument += ",";
                    }
                    checkedDocument += t.DocumentId;
                }
            });
            $scope.checkedDocumentId = checkedDocument;            
        }

        $scope.ShowDatepickerClick = function () {
            $scope.ShowDatepicker = true;
            $scope.ReadOnlyDatePicker = false;
        }

        $scope.fileList = [];
        $scope.FileUploadMultiple = function () {
            $scope.fileList = [];
            $scope.curFile;
            $scope.FileProperty = {
                file: ''
            }

            $scope.setFile = function (element) {
                $scope.fileList = [];
                // get the files
                var files = element.files;
                for (var i = 0; i < files.length; i++) {
                    $scope.FileProperty.file = files[i];

                    $scope.fileList.push($scope.FileProperty);
                    $scope.FileProperty = {};
                    $scope.$apply();

                }
            }
        }

        $scope.removeSelectedPic = function (filename) {
            console.log('file name--', filename);
            var i = $scope.fileList.indexOf('filename', filename);
            console.log('i--', i);
            $scope.fileList.splice(i, 1);
        }

        $scope.SaveInspectionDue = function () {
            $scope.GetCheckedFacilitiesAndProcess();
            var PdfList = [];
            var CapacityTable = 0;
            var PlanElevationDrawing = 0;
            if ($scope.capacitytable === true) {
                CapacityTable = 1;
            }

            if ($scope.planelevationdrawing) {
                PlanElevationDrawing = 1;
            }
            for (var i = 0; i < $scope.fileList.length; i++) {

                $scope.UploadFileIndividual($scope.fileList[i].file,
                    $scope.fileList[i].file.name,
                    $scope.fileList[i].file.type,
                    $scope.fileList[i].file.size,
                    i);
                PdfList[i] = $scope.fileList[i].file.name;
            }
            console.log('-----File Information-------', PdfList);
            if (true) {

            }
            var config = {
                CustomerId: $scope.customerId, CustomerLocationId: $scope.customerLocationId, CustomerAreaID: $scope.customerAreaId,
                EmployeeId: $scope.employeeId, InspectionDate: $scope.inspectionDate, InspectionType: $scope.inspectionType,
                CADDocuments: $scope.cADDocuments, FacilitiesAreasIds: $scope.checkedFacilitiesId, ProcessOverviewIds: $scope.checkedProcessId,
                ReferenceDocumentIds: $scope.checkedDocumentId, inspectionFileDrawing: PdfList
            }
            console.log('SaveInspectionDue', config);

            return $http({
                url: '/api/pageview/saveInspectionDue',
                method: "POST",
                data: config,
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                if (response.data === "Ok") {
                    var url = '/Admin/ManageInspection';
                    window.location = url;
                }
                else {
                    $scope.errorNot = response.data;
                }
            }, function (error) {
                alert(error);
            });
        };


        $scope.UploadFileIndividual = function (fileToUpload, name, type, size, index) {
            //Create XMLHttpRequest Object
            var reqObj = new XMLHttpRequest();

            //open the object and set method of call(get/post), url to call, isAsynchronous(true/False)
            reqObj.open("POST", "/UploadDrawingFiles", true);

            //set Content-Type at request header.for file upload it's value must be multipart/form-data
            reqObj.setRequestHeader("Content-Type", "multipart/form-data");

            //Set Other header like file name,size and type
            reqObj.setRequestHeader('X-File-Name', name);
            reqObj.setRequestHeader('X-File-Type', type);
            reqObj.setRequestHeader('X-File-Size', size);

            // send the file
            reqObj.send(fileToUpload);


        }

        $scope.EditInspectionDue = function (Id) {
            $scope.GetCheckedFacilitiesAndProcess();
            var PdfList = [];

            for (var i = 0; i < $scope.fileList.length; i++) {

                $scope.UploadFileIndividual($scope.fileList[i].file,
                    $scope.fileList[i].file.name,
                    $scope.fileList[i].file.type,
                    $scope.fileList[i].file.size,
                    i);
                PdfList[i] = $scope.fileList[i].file.name;
            }

            var config = {
                CustomerId: $scope.customerId, CustomerLocationId: $scope.customerLocationId, CustomerAreaID: $scope.customerAreaId,
                EmployeeId: $scope.employeeId, InspectionDate: $scope.inspectionDate, InspectionType: $scope.inspectionType, InspectionId: Id,
                CADDocuments: $scope.cADDocuments, FacilitiesAreasIds: $scope.checkedFacilitiesId, ProcessOverviewIds: $scope.checkedProcessId,
                InspectionStatus: $scope.inspectionStatus, ReferenceDocumentIds: $scope.checkedDocumentId, inspectionFileDrawing: PdfList
            }
            console.log('editInspectionDue', config);
            return $http({
                url: '/api/pageview/editInspectionDue',
                method: "POST",
                data: config,
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                if (response.data === "Ok") {
                    var url = '/Admin/ManageInspectionDue';
                    window.location = url;
                }
            }, function (error) {
                alert(error);
            });
        };

        $scope.RemoveInspectionDue = function (id) {
            var config = { id: id }
            console.log('Remove Inspection --', config);
            return $http({
                url: '/api/pageview/removeInspectionDue',
                method: "POST",
                params: config,
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                console.log('Remove Inspection Success --', response);
                if (response.data === "Ok") {
                    var url = '/Admin/ManageInspection';
                    window.location = url;
                }
            }, function (error) {
                alert(error);
            });
        };

        if (window.location.pathname == "/Admin/InspectionSheet" || window.location.pathname == "/Customer/InspectionDetails" || window.location.pathname == "/Employee/InspectionDetail") {

            var para = window.location.search;
            console.log('para inspection sheet', para);
            para = para.replace('?id=', '');
            console.log('para inspection sheet2', para);
            $http.get('/api/pageview/getInspectionDetailsForSheet', { params: { id: para } }).then(function (response) {
                $scope.getInspectionDetailsForSheet = response.data;
                console.log('*************', $scope.getInspectionDetailsForSheet);

                $scope.FacilitiesAreas = $scope.getInspectionDetailsForSheet.FacilitiesAreas;
                $scope.facilitiesAreasList = new Array();
                $scope.facilitiesAreasList = $scope.FacilitiesAreas.substring(0, $scope.FacilitiesAreas.length - 1);
                $scope.facilitiesAreasList = $scope.facilitiesAreasList.split(',');
                console.log('$scope.facilitiesAreasList', $scope.facilitiesAreasList);

                $scope.ProcessOverview = $scope.getInspectionDetailsForSheet.ProcessOverviews;
                $scope.processOverviewList = new Array();
                $scope.processOverviewList = $scope.ProcessOverview.substring(0, $scope.ProcessOverview.length - 1);
                $scope.processOverviewList = $scope.processOverviewList.split(';');
                console.log('$scope.ProcessOverviewList', $scope.processOverviewList);

                var contacts = $scope.getInspectionDetailsForSheet.CustomerContactIds;
                console.log('contactsId', contacts);
                console.log('2222', $scope.getInspectionDetailsForSheet.ListCustomerLocationContacts);
                angular.forEach($scope.getInspectionDetailsForSheet.ListCustomerLocationContacts, function (Contact) {
                    if (contacts.indexOf(Contact.LocationContactId) > -1) {
                        Contact.selected = true;
                    }
                });

                //var defIds = $scope.getInspectionDetailsForSheet.InspectionDeficiencyAdminStatus;
                //console.log('defIds', defIds);
                //console.log('dfvdr', $scope.getInspectionDetailsForSheet.iDefModel);
                //angular.forEach($scope.getInspectionDetailsForSheet.iDefModel, function (d) {
                //    if (defIds.indexOf(d.InspectionDeficiencyId) > -1) {
                //        d.selected = true;
                //    }
                //});
                console.log('$scope.getInspectionDetailsForSheet---------XXXXXX', $scope.getInspectionDetailsForSheet);

            }, function (response) {
                $scope.waiting = false;
            });
        }

        $scope.ApproveInspectionClick = function (id) {
            console.log("From Inspection details Ctrl - YXYXYXYXYXY----XXXXXXXXXXXXXXXXX ");
            var chkedSentEmailtoCustomer = "0";
            var chkInspectionStatus = 0;
            var istampingengineerid = 0;
            console.log('XXXXXX----XXXXXXXXXXXXXXXXX', $scope.chkSentEmailtoCustomer);
            if ($scope.chkInspectionStatus == 4) {
                chkInspectionStatus = $scope.chkInspectionStatus;
            }
            if ($scope.chkSentEmailtoCustomer === undefined) {
                chkedSentEmailtoCustomer = "0";
            }
            else {
                chkedSentEmailtoCustomer = $scope.chkSentEmailtoCustomer;
            }

            if ($scope.stampingengineerid === undefined) {
                istampingengineerid = "0";
            }
            else {
                istampingengineerid = $scope.stampingengineerid;
            }
            console.log('stampingengineerid-------', $scope.stampingengineerid);
            console.log('chkedSentEmailtoCustomer0--', chkedSentEmailtoCustomer);
            console.log('editInspectionStatus0', $scope.chkInspectionStatus);

            //if ($scope.chkInspectionStatus == 4) {
            //    InspectionStatus: $scope.chkInspectionStatus
            //}

            var checkedIspectionDeficiencyId = '';
            if ($scope.getInspectionDetailsForSheet.iDefModel != null) {
                $scope.getInspectionDetailsForSheet.iDefModel.forEach(function (d) {
                    if (d.selected) {
                        if (checkedIspectionDeficiencyId != '') {
                            checkedIspectionDeficiencyId += ",";
                        }
                        checkedIspectionDeficiencyId += d.InspectionDeficiencyId;
                    }
                });
            }
            console.log('XXXXXX', checkedIspectionDeficiencyId);
            var checkedDocument = '';
            $scope.getAllDocumentTitleInspection.forEach(function (t) {
                if (t.selected) {
                    if (checkedDocument != '') {
                        checkedDocument += ",";
                    }
                    checkedDocument += t.DocumentId;
                }
            });

            var data = {
                inspectionId: id,
                iInspectionStatus: chkInspectionStatus,
                iAdminIspectionDeficiencyIdStatus: checkedIspectionDeficiencyId,
                iStampingEngineerId: istampingengineerid,
                sCheckedDocument: checkedDocument
            }

            console.log('----XXXXtempXXXXXX NOT Selected InspectiondetailCtrl----', data);

            var checkedLocationContactId = '';
            if ($scope.getInspectionDetailsForSheet.ListCustomerLocationContacts != null) {
                $scope.getInspectionDetailsForSheet.ListCustomerLocationContacts.forEach(function (Contact) {
                    if (Contact.selected) {
                        checkedLocationContactId += Contact.LocationContactId + ",";
                    }
                    else {
                        /*      console.log('----XXXXtempXXXXXX NOT Selected----', checkedLocationContactId);*/
                    }
                });
            }
            else {
                checkedLocationContactId = '';
            }

            return $http({
                url: '/api/pageview/SaveUpdateApproveInspectionAdmin',
                method: "POST",
                params: data,
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                if (response.data === "Ok") {
                    if (chkedSentEmailtoCustomer == '1') {
                        console.log('Send email', checkedLocationContactId);
                        if (checkedLocationContactId == '') {
                            checkedLocationContactId = '0,0';
                        }
                        if (checkedLocationContactId !== '') {
                            var config = {
                                InspectionId: id, LocationContactId: checkedLocationContactId, SentToClient: chkedSentEmailtoCustomer
                            }
                            return $http({
                                url: '/Account/SendEmailOfPDF',
                                method: "POST",
                                data: config,
                                headers: {
                                    "Content-Type": "application/json",
                                    'RequestVerificationToken': $scope.antiForgeryToken
                                }
                            }).then(function (response) {
                                var url = '/Admin/ManageInspection';
                                window.location = url;
                            }, function (error) {
                                alert(error);
                            });
                        }
                    }
                    else {
                        var url = '/Admin/ManageInspection';
                        window.location = url;
                    }
                }
            }, function (error) {
                alert(error);
            });

            //if (checkedIspectionDeficiencyId != '') {
            //    var data = {
            //        inspectionId: id, iAdminStatus: checkedIspectionDeficiencyId
            //    }

            //    //console.log('adminStatusOk1--', adminStatusOk);
            //    return $http({
            //        url: '/api/pageview/saveInspectionDeficiencyAdminStatus',
            //        method: "POST",
            //        params: data,
            //        headers: {
            //            "Content-Type": "application/json"
            //        }
            //    }).then(function (response) {
            //        if (response.data === "Ok") {
            //            $scope.adminStatusOk = response.data;
            //            console.log('adminStatusOk1--', $scope.adminStatusOk);
            //            //window.localStorage.setItem("adminStatusOk", response.data);
            //        }
            //    }, function (error) {
            //        alert(error);
            //    });
            //}
            //console.log('checkedLocationContactId0--- on set');
            //var checkedLocationContactId = '';
            //if ($scope.getInspectionDetailsForSheet.ListCustomerLocationContacts != null) {
            //    $scope.getInspectionDetailsForSheet.ListCustomerLocationContacts.forEach(function (Contact) {
            //        if (Contact.selected) {
            //            checkedLocationContactId += Contact.LocationContactId + ",";
            //        }
            //        else {
            //            /*      console.log('----XXXXtempXXXXXX NOT Selected----', checkedLocationContactId);*/
            //        }
            //    });
            //}
            //else {
            //    checkedLocationContactId = '';
            //}
            //console.log('checkedLocationContactId0', checkedLocationContactId);
            //$scope.inspectionStatusOk = "";
            //$scope.adminStatusOk = "";
            //$scope.mailOk = "";



            //if ($scope.chkInspectionStatus == 4) {
            //    console.log('Yes', $scope.chkInspectionStatus);
            //    var data = {
            //        InspectionId: id, InspectionStatus: $scope.chkInspectionStatus
            //    }
            //    //inspectionStatusOk = "Ok";
            //    //console.log('inspectionStatusOk1--', inspectionStatusOk);
            //    return $http({
            //        url: '/api/pageview/editInspectionStatus',
            //        method: "POST",
            //        params: data,
            //        headers: {
            //            "Content-Type": "application/json"
            //        }
            //    }).then(function (response) {
            //        if (response.data === "Ok") {
            //            $scope.inspectionStatusOk = response.data;
            //            window.localStorage.setItem("inspectionStatusOkN", "Ok");
            //            console.log('inspectionStatusOk1--', $scope.inspectionStatusOk);
            //            console.log('----------------XXXXXXXXXXXXXXX--');

            //            console.log('----------------YYYYYYYYYYYYYYYYYYYYYYYYYY--', chkedSentEmailtoCustomer);
            //            if (chkedSentEmailtoCustomer == '9999') {
            //                if (checkedLocationContactId == '') {
            //                    checkedLocationContactId = '0,0';
            //                }
            //                if (checkedLocationContactId !== '') {
            //                    var config = {
            //                        InspectionId: id, LocationContactId: checkedLocationContactId, SentToClient: chkedSentEmailtoCustomer
            //                    }

            //                    $scope.mailOk = "Ok";
            //                    console.log('mailOk1--', $scope.mailOk);
            //                    window.localStorage.setItem("mailOk", "Ok");
            //                    return $http({
            //                        url: '/Account/SendEmailOfPDF',
            //                        method: "POST",
            //                        data: config,
            //                        headers: {
            //                            "Content-Type": "application/json",
            //                            'RequestVerificationToken': $scope.antiForgeryToken
            //                        }
            //                    }).then(function (response) {
            //                        $scope.mailOk = response.data;
            //                        console.log('local storage inspectionStatusOkN-', window.localStorage.getItem("inspectionStatusOkN"));
            //                        if (window.localStorage.getItem("adminStatusOk") == "Ok" || window.localStorage.getItem("mailOk") == "Ok" || window.localStorage.getItem("inspectionStatusOk") == "Ok") {
            //                            console.log('okokokokokok--');
            //                            console.log('inspectionStatusOk--', $scope.inspectionStatusOk);
            //                            console.log('adminStatusOk--', $scope.adminStatusOk);
            //                            console.log('mailOk--', $scope.mailOk);
            //                            var url = '/Admin/ManageInspection';
            //                            window.location = url;
            //                        }
            //                        if ($scope.inspectionStatusOk == "Ok" || $scope.adminStatusOk == "Ok" || $scope.mailOk == "Ok") {
            //                            console.log('okokokokokok--');
            //                            console.log('inspectionStatusOk--', $scope.inspectionStatusOk);
            //                            console.log('adminStatusOk--', $scope.adminStatusOk);
            //                            console.log('mailOk--', $scope.mailOk);
            //                            var url = '/Admin/ManageInspection';
            //                            window.location = url;
            //                        }
            //                    }, function (error) {
            //                        alert(error);
            //                    });
            //                }
            //            }

            //        }
            //    }, function (error) {
            //        alert(error);
            //    });
            //}




            //if (chkedSentEmailtoCustomer == '9999' || checkedIspectionDeficiencyId != '' || $scope.chkInspectionStatus === 4) {

            //}



            //console.log('XCCXCXC---', checkedLocationContactId);

            //$.each(temp, function (index, value) {
            //    //console.log('----XXXXtempXXXXXX Index----', index);
            //    console.log('----XXXXtempXXXXXX Value----', value[0]);
            //    //$('select.mrdDisplayBox').addOption(value.Id, value.Id + ' - ' + value.Number, false);
            //});

            //if (temp === null) {
            //    checkedLocationContactId = '';
            //}
            //else {
            //    $scope.getInspectionDetailsForSheet.ListCustomerLocationContacts.forEach(function (Contact) {
            //        if (Contact.selected) {
            //            if (checkedLocationContactId != '0,0') {
            //                //checkedLocationContactId = "0";
            //            }
            //            console.log('----XXXXtempXXXXXX----', checkedLocationContactId );
            //            checkedLocationContactId += Contact.LocationContactId + ",";
            //        }
            //    });
            //}

        }

        if (window.location.pathname == "/Admin/ManageInspectionFiles") {
            var insId = window.location.search;
            insId = insId.replace('?id=', '');
            $http.get('/api/pageview/getInspectionFileDrawingByInspectionId', { params: { id: insId } }).then(function (response) {
                $scope.getInspectionFileDrawing = response.data;
                console.log('$scope.getInspectionFileDrawing', $scope.getInspectionFileDrawing);
                if ($scope.getInspectionFileDrawing != null) { $scope.getInspectionFileDrawingcount = $scope.getInspectionFileDrawing.length; }
                else { $scope.getInspectionFileDrawingcount = 0; }
                $scope.totalgetInspectionFileDrawing = $scope.getInspectionFileDrawingcount;
            }, function (response) {
                $scope.waiting = false;
            });
        }

        $scope.SaveInspectionFile = function () {
            var insId = window.location.search;
            insId = insId.replace('?id=', '');
            var list = '';
            var PdfList = [];

            for (var i = 0; i < $scope.fileList.length; i++) {

                $scope.UploadFileIndividual($scope.fileList[i].file,
                    $scope.fileList[i].file.name,
                    $scope.fileList[i].file.type,
                    $scope.fileList[i].file.size,
                    i);
                PdfList[i] = $scope.fileList[i].file.name;

            }
            list = PdfList.toString();
            console.log('-----File Information-------', list);
            var config = { InspectionId: insId, FileCategory: $scope.fileCategory, FileDrawingPath: list }
            console.log('00000000000--', config);
            return $http({
                url: '/api/pageview/saveInspectionFileDrawing',
                method: "POST",
                data: config,
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                if (response.data != 0) {
                    $http.get('/api/pageview/getInspectionFileDrawingByInspectionId', { params: { id: response.data } }).then(function (response) {
                        $scope.getInspectionFileDrawing = response.data;
                        console.log('$scope.getInspectionFileDrawing', $scope.getInspectionFileDrawing);
                        if ($scope.getInspectionFileDrawing != null) { $scope.getInspectionFileDrawingcount = $scope.getInspectionFileDrawing.length; }
                        else { $scope.getInspectionFileDrawingcount = 0; }
                        $scope.totalgetInspectionFileDrawing = $scope.getInspectionFileDrawingcount;
                    }, function (response) {
                        $scope.waiting = false;
                    });
                    $scope.fileList = [];
                }
            });
        };

        $scope.RemoveInspectionFile = function (id) {
            var config = { id: id }
            console.log('return config-RemoveInspectionFile-', config);
            return $http({
                url: '/api/pageview/removeInspectionFileDrawing',
                method: "POST",
                params: config,
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function (response) {
                if (response.data != 0) {
                    var url = '/Admin/ManageInspectionFiles?id=' + response.data;
                    console.log('84848484-', url);
                    window.location = url;
                }
            });
        };
    }
})();
